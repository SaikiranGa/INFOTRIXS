<?php

$con= mysqli_connect("localhost", "root","","todo") or die("connection fail");
?>